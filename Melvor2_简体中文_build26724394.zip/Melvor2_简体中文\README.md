# Melvor Idle 2 正式 EA 一键简体中文补丁

适用：Steam 正式抢先体验版 **Melvor Idle 2: A RuneScape Adventure**，AppID **3218350**，build **26724394**（Windows x64）。由 Demo 汉化迁移，并以官方 `zh_CN` 目录补全新增内容。

实验性初稿，**尚未做游戏内显示验收**。本补丁改写 `Melvor2.exe` 内嵌 PCK 的 **`Locale/en_GB.po`**（当前版本工程设置只加载这一份语言包），**数字签名会失效**。

**不需要安装 Python**。双击脚本即可，依赖 Windows 自带的 PowerShell。不改 DLL / 存档 / 数值，也不会自动启动游戏。

## 怎么用

1. 把本文件夹放到游戏目录，与 `Melvor2.exe` **同一层**（不要只解压到桌面就运行）。
2. **完全退出游戏**（任务管理器里确认没有 Melvor2）。
3. 双击 **`一键汉化.cmd`**。窗口会显示进度，**大约 2–3 分钟**，请勿中途关闭。
4. 看到「成功」后再从 Steam 启动游戏。
5. 语言请选择 **English / en_GB**。这是本补丁的中文载体；官方虽附带 `Locale/zh_CN.po`，但本 build 的工程设置未把它列入已加载翻译，选「简体中文」可能不会生效。
6. 要还原官方英文版：退出游戏后双击 **`取消汉化.cmd`**。

版本不符或 Steam「验证游戏文件」后会恢复英文 EXE，需重新运行一键汉化。`backups/` 由脚本自动生成，请勿在安装/还原中途删除。

## 说明

当前目录以官方 `en_GB.po` 为准，共 11540 个 PO 键（1934 个复数）。译文优先采用官方完整 `zh_CN.po`，再合并 Demo 可用译文，并补上官方目录缺的语言界面条目、复数占位符和 `PluralName` 上下文。

若脚本报错，把黑色窗口里的红色失败信息发出来即可排查。

## If you deleted backups

- If Melvor2.exe is still this pack's patched build, run One-Click Patch again; it should report already installed.
- Cancel/Restore needs the official EXE backup. Without it, use Steam Verify Integrity of Game Files, then run One-Click Patch again to recreate backups.

## 物品名称修复

银行等界面会把物品英文原名交给 Godot 自动翻译（不带 PluralName 上下文），导致约 686 个只有上下文条目的物品名仍显示英文。本版已补上无上下文回退，并按游戏数据包原文补全了 18 个官方目录因拼写/单复数不一致而缺失的物品名。

若游戏正在运行，请先完全退出，再双击「一键汉化」（脚本会从官方备份重建，不会叠补丁）。